from django.contrib import admin
from kalas.models import UserProfileInfo,Post
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(Post)
