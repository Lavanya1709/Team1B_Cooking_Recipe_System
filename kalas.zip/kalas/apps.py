from django.apps import AppConfig

class KalasConfig(AppConfig):
    name = 'kalas'
