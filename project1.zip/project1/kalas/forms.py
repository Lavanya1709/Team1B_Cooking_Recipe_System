from django import forms
from django.contrib.auth.models import User
from kalas.models import UserProfileInfo, Post

class UserForm(forms.ModelForm):
    class Meta():
        model = UserProfileInfo
        fields = ('username','password','email')
class PostForm(forms.ModelForm):
    class Meta():
        model = Post
        fields = ('title','slug','body','publish','status')
