from django.shortcuts import render
from kalas.forms import UserForm,PostForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from kalas.models import UserProfileInfo

def index(request):
	   return render(request, 'index.html')
	   
@login_required
def special(request):
    return HttpResponse("You are logged in !")
    
def user_logout(request):
    logout(request)
    return render(request,'index.html')
def welcome(request):
	   return render(request,'welcome.html')
def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
       
        if user_form.is_valid():
            user = user_form.save()
            user.save()
            registered = True
            return render(request, 'menu.html',{'user_form':user_form,'registered':registered})
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
    return render(request,'register.html',{'user_form':user_form,'registered':registered})
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        a = UserProfileInfo.objects.filter(username=username).exists()
        b = UserProfileInfo.objects.filter(password=password).exists()
        if a and b:
            #login(request,user)
            return HttpResponseRedirect(reverse('menu'))
            #else:
                #return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'user_login.html')
def menu(request):
		return render(request,'menu.html')
def breakfast(request):
		return render(request,'breakfast.html')
def avada(request):
		return render(request,'avada.html')
def masaladosa(request):
		return render(request,'masaladosa.html')
def parota(request):
		return render(request,'parota.html')
def poori(request):
		return render(request,'poori.html')
def upmapesarattu(request):
		return render(request,'upmapesarattu.html')
def lunch(request):
		return render(request,'lunch.html')
def butterchicken(request):
		return render(request,'butterchicken.html')
def muttonbiryani(request):
		return render(request,'muttonbiryani.html')
def tandoorichicken(request):
		return render(request,'tandoorichicken.html')
def fishfry(request):
		return render(request,'fishfry.html')
def masalabhindi(request):
		return render(request,'masalabhindi.html')
def dinner(request):
		return render(request,'dinner.html')
def chickenbiryani(request):
		return render(request,'chickenbiryani.html')
def butter(request):
		return render(request,'butter.html')
def maharani(request):
		return render(request,'maharani.html')
def paneer(request):
		return render(request,'paneer.html')
def potato(request):
		return render(request,'potato.html')
def snacks(request):
		return render(request,'snacks.html')		
def coldcoffee(request):
	 return render(request,'coldcoffee.html')
def donuts(request):
	 return render(request,'donuts.html')
def milkshakes(request):
	 return render(request,'milkshakes.html')
def pastry(request):
	 return render(request,'pastry.html')
def pizza(request):
	 return render(request,'pizza.html')
def blog(request):
    registered = False
    if request.method == 'POST':
        post_form = PostForm(data=request.POST)
       
        if post_form.is_valid():
            user = post_form.save()
            user.save()
            registered = True
            return render(request, 'blog.html',{'post_form':post_form,'registered':registered})
        else:
            print(post_form.errors)
    else:
        post_form = PostForm()
    return render(request,'blog.html',{'post_form':post_form,'registered':registered})
# Create your views here.
